//当前选择后的字体颜色
var g_SelFontCol = '#131313';

//默认字体颜色
var g_defaultFontCol = '#89CFD8';

//当前Menu选择的ID
var curMenuSelID="";

//当前Item选择的ID
var curItemSelID="";

var DEVTYPE = "";
//设置变量命名
function setLeftModuleLang()
{
    /***即时影像*/
    document.getElementById("liveViewLabelID").innerHTML = liveViewLang;
    /***跟踪界面*/
    document.getElementById("trackLabelID").innerHTML = trackVideoLang;
    /*document.getElementById("trackSpanID").innerHTML = trackVideoLang;
	document.getElementById("trackViewHrefID").innerHTML = trackViewLang;
	document.getElementById("trackSetHrefID").innerHTML = trackSetLang;*/


    /***音讯*/
    document.getElementById("audioLabelID").innerHTML = audioLang;
    /***串流*/
    document.getElementById("streamLabelID").innerHTML = streamLang;
    
    /***系统设置*/
    document.getElementById("systemSettingsSpanID").innerHTML = systemSettingsLang;
    //输出设置
    document.getElementById("outputSetHrefID").innerHTML = outputLang;
    //网络
    document.getElementById("networkSetHrefID").innerHTML = networkLang;
    //日期/时间
    document.getElementById("timeSetHrefID").innerHTML = dateTimeLang;
    //使用者管理
    document.getElementById("userManageHrefID").innerHTML = userModuleLang;
    //控制设置
    document.getElementById("controlSetHrefID").innerHTML = controlSettingsLang;

    /***维护*/
    document.getElementById("maintainLabelID").innerHTML = systemMaintenanceLang;

    /***关于*/
    document.getElementById("aboutLabID").innerHTML = aboutLang;
}

//Init
function setLeftModuleInit()
{
    DEVTYPE = document.forms["hiddenValForm"].hcAboutMeModelName.value;

    $("#liveViewMenuID").show();
    if(DEVTYPE == "VC-TR40") {
        $("#trackMenuID").show(); 
    }else if(DEVTYPE == "VC-TR45") {
        $("#trackMenuID").show();
    }else if(DEVTYPE == "VC-TR30") {
        $("#trackMenuID").show();
    }else if(DEVTYPE == "VC-TR40N") {
        $("#trackMenuID").show();
    }else{
        $("#trackMenuID").hide();
    }
    
    $("#audioMenuID").show();
    $("#streamMenuID").show();
    $("#systemSettingsMenuID").show();
    $("#maintainMenuID").show();
    $("#aboutMenuID").show();
}

/**
 * 设置当前Menu ID、Item ID
 */
function setCurMenuItemSel(menuSel,itemSel)
{
    curMenuSelID = menuSel;
    curItemSelID = itemSel;
//	console.log("111111111111="+obj.id +",bSelect="+curItemSelID);
    //Init
    setLeftModuleInit();
    setTopType();
    //显示当前Menu
    setCurMenuStatus(curMenuSelID,true);
    setMenuStyle(curMenuSelID,true);

    //更改下拉图标状态
    setChangeSelectBar(curMenuSelID);

    //显示Item样式
    setItemStyle(curItemSelID,true);
}

/**
 * 当前Menu显示状态
 */
function setCurMenuStatus(curSel,bSelect)
{
    //判断当前选择的Menu
    if(curSel == "systemSettingsMenuID")
    {
        //系统配置
        if(bSelect)
        {
            $("#outputSetItemID").show();
            $("#networkSetItemID").show();
            $("#timeSetItemID").show();
            $("#userManageItemID").show();
            $("#controlSetItemID").show();
        }
        else
        {
            $("#outputSetItemID").hide();
            $("#networkSetItemID").hide();
            $("#timeSetItemID").hide();
            $("#userManageItemID").hide();
            $("#controlSetItemID").hide();
        }
    }

	if(curSel == "trackMenuID")
	{
        /*if(bSelect)
        {
            $("#trackViewMenuID").show();
            $("#trackSetMenuID").show();

        }
        else
        {
            $("#trackViewMenuID").hide();
            $("#trackSetMenuID").hide();

        }*/

	}


}

/**
 * 设置 Menu 风格
 */
function setMenuStyle(curSel,bSelect)
{
    //判断当前选择的Menu
    if(curSel == "liveViewMenuID")
    {
        //Live View
        var fontCol;
        var menuCSS;
        var imgCSS;

        //
        if(bSelect)
        {
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/live_view_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/live_view_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#liveViewMenuID").css('background',menuCSS);
        $("#liveViewImgID").css('content',imgCSS);

        //更改Menu字体颜色
        $("#liveViewLabelID").css('color',fontCol);
    }
    else if (curSel == "trackMenuID")
    {
        //Track View
        var fontCol;
        var menuCSS;
        var imgCSS;
		//var selImgCSS;
        //
        if(bSelect)
        {
//            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
//            imgCSS = 'url(../images/MainView/live_view_h.png)';
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/menu-icon_tracking_h.png)';
           // selImgCSS = 'url(../images/MainView/select_bar_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
//            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
//            imgCSS = 'url(../images/MainView/live_view_n.png)';
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/menu-icon_tracking_n.png)';
           // selImgCSS = 'url(../images/MainView/select_bar_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#trackMenuID").css('background',menuCSS);
        $("#trackImgID").css('content',imgCSS);
		//$("#trackSelectSelImgID").css('content',selImgCSS);

        //更改Menu字体颜色
        $("#trackLabelID").css('color',fontCol);


    }
    else if(curSel == "audioMenuID")
    {
        //Audio
        var fontCol;
        var menuCSS;
        var imgCSS;

        //
        if(bSelect)
        {
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/audio_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/audio_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#audioMenuID").css('background',menuCSS);
        $("#audioImgID").css('content',imgCSS);

        //更改Menu字体颜色
        $("#audioLabelID").css('color',fontCol);
    }
    else if(curSel == "streamMenuID")
    {
        //Stream
        var fontCol;
        var menuCSS;
        var imgCSS;

        //
        if(bSelect)
        {
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/stream_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/stream_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#streamMenuID").css('background',menuCSS);
        $("#streamImgID").css('content',imgCSS);

        //更改Menu字体颜色
        $("#streamLabelID").css('color',fontCol);
    }
    else if(curSel == "systemSettingsMenuID")
    {
        //系统配置
        var fontCol;
        var menuCSS;
        var imgCSS;
        var selImgCSS;
        //
        if(bSelect)
        {

            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/system_settings_h.png)';
            selImgCSS = 'url(../images/MainView/select_bar_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/system_settings_n.png)';
            selImgCSS = 'url(../images/MainView/select_bar_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#systemSettingsMenuID").css('background',menuCSS);
        $("#systemSettingsImgID").css('content',imgCSS);
        $("#systemSettingsSelImgID").css('content',selImgCSS);

        //更改Menu字体颜色
        $("#systemSettingsSpanID").css('color',fontCol);
    }
    else if(curSel == "maintainMenuID")
    {
        //维护
        var fontCol;
        var menuCSS;
        var imgCSS;
        //
        if(bSelect)
        {
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/maintain_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/maintain_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#maintainMenuID").css('background',menuCSS);
        $("#maintainImgID").css('content',imgCSS);

        //更改Menu字体颜色
        $("#maintainLabelID").css('color',fontCol);
    }
    else if(curSel == "aboutMenuID")
    {
        //关于
        var fontCol;
        var menuCSS;
        var imgCSS;
        //
        if(bSelect)
        {
            menuCSS = 'url(../images/MainView/list_menu_h.png) no-repeat';
            imgCSS = 'url(../images/MainView/about_h.png)';

            fontCol = g_SelFontCol;
        }
        else
        {
            menuCSS = 'url(../images/MainView/list_menu_n.png) no-repeat';
            imgCSS = 'url(../images/MainView/about_n.png)';

            fontCol = g_defaultFontCol;
        }

        //更改Menu背景色
        $("#aboutMenuID").css('background',menuCSS);
        $("#aboutImgID").css('content',imgCSS);

        //更改Menu字体颜色
        $("#aboutLabID").css('color',fontCol);
    }
}

/**
 * 设置 Item 风格
 */
function setItemStyle(curSel,bSelect)
{
//	console.log("curSel="+curSel +",bSelect="+bSelect);
    //判断当前选择的Item
    if(curSel == "outputSetItemID")
    {
        //输入设置
        if(bSelect)
        {
            //更改Item背景色
            $("#outputSetItemID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#outputSetHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#outputSetItemID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#outputSetHrefID").css('color',g_defaultFontCol);
        }
    }
    else if(curSel == "networkSetItemID")
    {
        //网络设置
        if(bSelect)
        {
            //更改Item背景色
            $("#networkSetItemID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#networkSetHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#networkSetItemID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#networkSetHrefID").css('color',g_defaultFontCol);
        }
    }
    else if(curSel == "timeSetItemID")
    {
        //时间设置
        if(bSelect)
        {
            //更改Item背景色
            $("#timeSetItemID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#timeSetHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#timeSetItemID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#timeSetHrefID").css('color',g_defaultFontCol);
        }
    }
    else if(curSel == "userManageItemID")
    {
        //用户管理
        if(bSelect)
        {
            //更改Item背景色
            $("#userManageItemID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#userManageHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#userManageItemID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#userManageHrefID").css('color',g_defaultFontCol);
        }
    }
    else if(curSel == "controlSetItemID")
    {
        //控制设置
        if(bSelect)
        {
            //更改Item背景色
            $("#controlSetItemID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#controlSetHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#controlSetItemID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#controlSetHrefID").css('color',g_defaultFontCol);
        }
    }
	/*else if(curSel == "trackViewMenuID")
    {
        if(bSelect)
        {
            //更改Item背景色
            $("#trackViewMenuID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#trackViewHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#trackViewMenuID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#trackViewHrefID").css('color',g_defaultFontCol);
        }
    }
    else if(curSel == "trackSetMenuID")
    {

        if(bSelect)
        {
            //更改Item背景色
            $("#trackSetMenuID").css('background','url(../images/MainView/list_item_h.png) no-repeat');
            //更改字体颜色
            $("#trackSetHrefID").css('color',g_SelFontCol);
        }
        else
        {
            //更改Item背景色
            $("#trackSetMenuID").css('background','url(../images/MainView/list_item_n.png) no-repeat');
            //更改字体颜色
            $("#trackSetHrefID").css('color',g_defaultFontCol);
        }
	}*/


}
/**
 * 更改下拉图标状态
 */
function setChangeSelectBar(curSel)
{
    //判断当前选择的Menu
    if(curSel == "systemSettingsMenuID")
    {
        $("#systemSettingsSelImgID").css('content','url(../images/MainView/select_bar_p.png)');
    }


    if(curSel == "trackMenuID")
    {
        $("#trackSelectSelImgID").css('content','url(../images/MainView/select_bar_p.png)');
    }

}


/**
 * Menu点击实现折叠和显示
 */
function onMenuclick(obj)
{
    //上一个Menu设置为未选中状态
    if(obj.id != curMenuSelID)
    {
        //隐藏
        setCurMenuStatus(curMenuSelID,false);
        setMenuStyle(curMenuSelID,false);

        //更新当前选中ID
        curMenuSelID = obj.id;
    }

    var bShow = false;
    //当前ID
    if(obj.id == "systemSettingsMenuID")
    {
        //系统配置
        //判断Item是否已经隐藏
        if($('#outputSetItemID').is(':hidden'))
        {
            //如果隐藏,则显示
            bShow = true;
        }
    }
    else if(obj.id == "trackMenuID")
    {
        //系统配置
        //判断Item是否已经隐藏
        /*if($('#trackViewMenuID').is(':hidden'))
        {
            //如果隐藏,则显示
            bShow = true;
        }*/
    }

    //展示
    setCurMenuStatus(curMenuSelID,bShow);
    setMenuStyle(curMenuSelID,true);

    if(bShow)
    {
        //更改下拉图标状态
        setChangeSelectBar(curMenuSelID);
    }
}

/**
 * Menu Mouse Over
 */
 function onMenuMouseOver(obj)
 {
    if(obj.id != curMenuSelID)
    {
        setMenuStyle(obj.id,true);
    }
 }
 
 /**
  * Menu Mouse Out
  */
 function onMenuMouseOut(obj)
 {
    if(obj.id == curMenuSelID)
        return;

    setMenuStyle(obj.id,false);
 }

 /**
 * Item 选择
 */
function onItemclick(obj)
{   
    //上一个Item设置为未选中状态
    if(obj.id != curItemSelID)
    {
        //设置未选中状态
        setItemStyle(curItemSelID,false);

        //更新当前选中ID
        curItemSelID = obj.id;
    }

    //设置选中
    setItemStyle(curItemSelID,true);
}

/**
 * Item Mouse Over
 */

 function onItemMouseOver(obj)
 {
    setItemStyle(obj.id,true);
 }
 
 /**
  * Item Mouse Out
  */
 function onItemMouseOut(obj)
 {
    if(obj.id == curItemSelID)
        return;

    setItemStyle(obj.id,false);
 }


//  据用户权限显示模块状态
function setLeftModuleStatus(userType)
{
    if(userType == "")
        return;

    if("1" == userType || "2" == userType)
    {
        // Operator And Viewer

        //Audio
        $("#audioMenuID").hide();
        //Stream
        $("#streamMenuID").hide();
        //System Settings
        $("#systemSettingsMenuID").hide(); 
        //Maintenance
        $("#maintainMenuID").hide();
        //Viewer隐藏trackMenuID
        if("2" == userType)
        {
            $("#trackMenuID").hide();
        }
    }
}

//根据设备状态来设置Menu样式
function setMenuStyleByDevStatus(devStatus)
{
    if(devStatus == power_off)
    {
        //待机状态
        let menuCSS = 'url(../images/MainView/list_menu_d.png) no-repeat';

        //live View
        $("#liveViewMenuID").css('background',menuCSS);

        $("#liveViewImgID").css('content','url(../images/MainView/live_view_d.png)');
        $("#liveViewLabelID").css('color',g_disableFontCol2);

        $("#liveViewMenuID").css({"pointer-events": "none" });
        
        //Tracking
        $("#trackMenuID").css('background',menuCSS);
        $("#trackImgID").css('content','url(../images/MainView/menu-icon_tracking_d.png)');
        $("#trackLabelID").css('color',g_disableFontCol2);
        $("#trackMenuID").css({"pointer-events": "none" });

        //Audio
        $("#audioMenuID").css('background',menuCSS);

        $("#audioImgID").css('content','url(../images/MainView/audio_d.png)');
        $("#audioLabelID").css('color',g_disableFontCol2);

        $("#audioMenuID").css({"pointer-events": "none" });

        //Stream
        $("#streamMenuID").css('background',menuCSS);

        $("#streamImgID").css('content','url(../images/MainView/stream_d.png)');
        $("#streamLabelID").css('color',g_disableFontCol2);

        $("#streamMenuID").css({"pointer-events": "none" });

        //System Settings
        $("#systemSettingsMenuID").css('background',menuCSS);

        $("#systemSettingsImgID").css('content','url(../images/MainView/system_settings_d.png)');
        $("#systemSettingsSelImgID").css('content','url(../images/MainView/select_bar_d.png)');
        $("#systemSettingsSpanID").css('color',g_disableFontCol2);

        $("#systemSettingsMenuID").css({"pointer-events": "none" });

        //Maintenance
        $("#maintainMenuID").css('background',menuCSS);

        $("#maintainImgID").css('content','url(../images/MainView/maintain_d.png)');
        $("#maintainLabelID").css('color',g_disableFontCol2);

        $("#maintainMenuID").css({"pointer-events": "none" });
    }
}