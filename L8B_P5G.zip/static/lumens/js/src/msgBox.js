/*
 * msgBox
 */


/******************************************************************************************
 *                                          对话框
 *******************************************************************************************/
function mkElem(tag, attrs, child) {
  var elem = $("<"+tag+" />").attr(attrs);
  var childArray = $.makeArray(child);
  $.each(childArray, function(i, c){
    elem.append(c);
  });
  return elem;
}

function mkElemClass(tag, classes, child) {
  return mkElem(tag, {"class":classes}, child);
}

function mkModal(id, extraClasses, title, body, footer, canClose, closeHndlr) {
  return  mkElem("div", {id:id, "class":"modal hide " + extraClasses}, [
            mkElemClass("div", "msgTitleDiv", [
              // mkElem("h3", {}, title)
              mkElemClass("label", "titleLabel", title),
              canClose ?
                  mkElem("button", {"type":"button","class":"btn close","data-dismiss":"modal"},"&#215;").click(closeHndlr)
                : null
            ]),
            mkElemClass("div", "modal-body msgInfoDiv", mkElem("p", {}, body)),
            mkElemClass("div", "modal-footer msgCtrlDiv", footer)
          ]);
}

var standardModalOptions = {backdrop:"static", keyboard: false};

function mkModalElem(id, extraClasses, title, body, footer, options, canClose, closeHndlr) {
  var elem = mkElem("div", {id:id, "class":"modal hide " + extraClasses}, [
            mkElemClass("div", "msgTitleDiv", [
              // mkElem("h3", {}, title)
              mkElemClass("label", "titleLabel", title),
              canClose ?
                  mkElem("button", {"type":"button","class":"btn close","data-dismiss":"modal"},"&#215;").click(closeHndlr)
                : null
            ]),
            mkElemClass("div", "modal-body msgInfoDiv", mkElem("p", {}, body)),
            mkElemClass("div", "modal-footer msgCtrlDiv", footer)
          ]);
  $(elem).modal(options);

  return elem;
}

// Self made hack to curry a function!
function curry(f) 
{
    var args = $.makeArray(arguments).slice(1);
    if(args.length < 1)
    {
        
    }
    return function()
    { 
        if (f)
        {
            return f.apply(this, args.concat($.makeArray(arguments)));
        }
    };
}

//提示对话框
function showMessageModal(title, body, onClose) {

  mkModalElem("msgModal", "", title, body, 
                mkElem("button", {id:"MSG_BT","type":"button","class":"okBtn","data-dismiss":"modal"},okLang).click(onClose),
                standardModalOptions,
                true,  /* canClose */
                onClose
              );
	
	//document.getElementById("MSG_BT").blur();
	document.getElementById("MSG_BT").focus();
}

//选择对话框
function showConfirmationModal(title, body, yesHndlr, noHndlr, isDangerous) {
  var yesClass = isDangerous ? "btn-danger" : "btn-primary";
  var modalElem;
  modalElem= mkModal("confirmModal", "", title, body, [
    mkElem("button", {"type":"button","class":"okBtn","data-dismiss":"modal"},yesLang).click(yesHndlr),
    mkElem("button", {"type":"button","class":"okBtn","data-dismiss":"modal"},noLang).click(noHndlr)
        ],
        true  /* canClose */,
        noHndlr
  );
	
  $(modalElem).modal(standardModalOptions);
}


/******************************************************************************************
 *                                          UI界面锁定
 *******************************************************************************************/
function blockUIforPage(info){
  $.blockUI({ css: { 
           border: 'none', 
           padding: '15px', 
           backgroundColor: '#000', 
           '-webkit-border-radius': '10px', 
           '-moz-border-radius': '10px', 
           opacity: .6, 
           color: '#ffffff' 
       },
       message:  '<label class=\'uiBlockLabel\'>'+info+'</label>'
       }); 
}

var uitimeout = -1;
var uiinfo = "";
var prvinfo;
function unblockUIforPage(){
    $.unblockUI();
    uitimeout = -1;
    prvinfo = "";
    if(uiinfo != "")
    {
        showMessageModal(msgTitleLang, uiinfo);
    }
}


function SetunblockUIforPage(timeout,timeoutinfo){
    if(uitimeout != -1)
    {
        clearTimeout(uitimeout);
    }
    uiinfo = timeoutinfo;
    uitimeout = setTimeout("unblockUIforPage()", timeout);
}

// 例子
function resetAction(timeout ,info, timeoutinfo) {
    if(prvinfo != info && info != "")
    {
        prvinfo = info;
        blockUIforPage(info);
    }
	
  //等待多少时间解锁界面
	SetunblockUIforPage(timeout,timeoutinfo);
}

