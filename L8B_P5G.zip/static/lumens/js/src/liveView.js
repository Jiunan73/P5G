var focusMode="";

//用户角色 0:Admin  1:Operator  2:Viewer
let userPerm ="";

//当前操作模块 0:PtzCtrl  1:CameraCtrl 2:AutoFraming
let gCurCtrlModule = 0;

//鼠标是否按下
var g_bMousePress = false;
/////////////////////////////////////////////////////////////////////////
//Pan Tilt Speed
const gPanTiltMinSpeed = 0;
const gPanTiltMaxSpeed = 8;
//Zoom Speed
const gZoomMinSpeed = 0;
const gZoomMaxSpeed = 8;
/////////////////////////////////////////////////////////////////////////
//当前模块
var curModule = "";
//当前帧率
let gCurFrameRate = "30";

//当前页面操作的数据信息及状态
var operateData = "";
var oldstatus   = "";
var newstatus   = "";

//Gain
var gainParamArr = ["0dB","+2dB","+4dB","+6dB","+8dB","+10dB","+12dB","+14dB","+16dB","+18dB","+20dB","+22dB"
                        ,"+24dB","+26dB","+28dB","+30dB"];
var gainParamVal = ["0","2","4","6","8","10","12","14","16","18","20","22"
                        ,"24","26","28","30"];

var curGainIndex = 0;

//Gain Limit
let gainLimitArr = ["8dB","10dB","12dB","14dB","16dB","18dB","20dB","22dB","24dB","26dB","28dB","30dB"];
let gainLimitVal = ["8","10","12","14","16","18","20","22","24","26","28","30"];
let curGainLimitIndex = 0;

//Iris
// var irisParamArr = ["Close" ,"F1.6" ,"F2"   ,"F2.4" ,"F2.8" ,"F3.4" ,"F4"   ,"F4.8" ,"F5.6" ,"F6.8" ,"F8"   ,"F9.6" ,"F11"  ,"F14"  ];
// var irisParamVal = ["13"    ,"12"   ,"11"   ,"10"   ,"9"    ,"8"    ,"7"    ,"6"    ,"5"     ,"4"   ,"3"    ,"2"    ,"1"    ,"0"    ];
var irisParamArr = ["Close" ,"F14"  ,"F11"  ,"F9.6" ,"F8"   ,"F6.8" ,"F5.6" ,"F4.8" ,"F4"   ,"F3.4" ,"F2.8" ,"F2.4" ,"F2"   ,"F1.6" ];
var irisParamVal = ["0"     ,"1"    ,"2"    ,"3"    ,"4"    ,"5"    ,"6"    ,"7"    ,"8"    ,"9"    ,"10"   ,"11"   ,"12"   ,"13"    ];
var curIrisIndex = 0;

/***Shutter Speed*/
//FrameRate=30
var shutterSpeedParamArr = ["1/10000","1/5000","1/3000","1/2500","1/2000","1/1500","1/1000","1/725","1/500"
                            ,"1/350","1/250","1/180","1/120","1/100","1/90","1/60","1/30"];

//FrameRate=25
let shutterSpeedParam25Arr = ["1/10000","1/5000","1/3000","1/2500","1/1750","1/1250","1/1000","1/600","1/425"
                            ,"1/300","1/215","1/150","1/120","1/100","1/75","1/50","1/25"];

var shutterSpeedParamVal = ["21","20","19","18","17","16","15","14","13"
                            ,"12","11","10","9","8","7","6","5"];

var curShutterSpeedIndex = 0;


//Pan/Tilt Limit Value
var g_iPanRightLimVal = 170;
var g_iPanLeftLimVal = -170;
var g_iTiltUpLimVal = 90;
var g_iTiltDownLimVal = -30;

//
function onVideoWndDivMouseOver()
{
    //Viewer
    if(userPerm == "2")
        return;

    if($('#reserveDivId').is(':hidden'))
    {
        $("#videoWndMaxID").css('background','url(../images/MainView/Ptz/narrow_h.png) no-repeat');
    }
    else
    {
        $("#videoWndMaxID").css('background','url(../images/MainView/Ptz/enlarge_h.png) no-repeat');
    }

    //Show
    $("#videoWndMaxID").show();
}

function onVideoWndDivMouseOut()
{
    //Hide
    $("#videoWndMaxID").hide();
}

function onVideoWndMaxBtn()
{
    if($('#reserveDivId').is(':hidden'))
    {
        //当前模块
        switch (gCurCtrlModule) {
            case 0:
                {
                    //Ptz Ctrl
                    $("#cameraCtrlDivId").show();
                }    
                break;
            case 1:
                {
                    //Camera Ctrl
                    $("#cameraSettingsDivId").show();
                }    
                break;
            case 2:
                {
                    //auto framing
                    $("#autoFramSettingsDivId").show();
                }    
                break;
            default:
                break;
        }

         //Reserve
        $("#reserveDivId").show();

        $("#videoWndMaxID").css('background','url(../images/MainView/Ptz/enlarge_h.png) no-repeat');
    }
    else
    {
        //Ptz Ctrl
        $("#cameraCtrlDivId").hide();
        //Camera Ctrl
        $("#cameraSettingsDivId").hide();
        //auto framing
        $("#autoFramSettingsDivId").hide();
        //Reserve
        $("#reserveDivId").hide();

        $("#videoWndMaxID").css('background','url(../images/MainView/Ptz/narrow_h.png) no-repeat');
    }
}

//云台控制
function onPtzCtrlBtn(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    //当前控制命令
    var ptzCtrlCmd="";

    //判断当前BtnID
   if(obj.id == "ptzLeftUpID")
   {
        //左上
        ptzCtrlCmd="&cPtzControlLeftUp=";
   }
   else if(obj.id == "ptzUpID")
   {
       //上
       ptzCtrlCmd="&cPtzControlUp=";
   }
   else if(obj.id == "ptzRightUpID")
   {
       //右上
       ptzCtrlCmd="&cPtzControlRightUp=";
   }
   else if(obj.id == "ptzLeftID")
   {
       //左
       ptzCtrlCmd="&cPtzControlLeft=";
   }
   else if(obj.id == "ptzRightID")
   {
       //右
       ptzCtrlCmd="&cPtzControlRight=";
   }
   else if(obj.id == "ptzLeftDownID")
   {
       //左下
       ptzCtrlCmd="&cPtzControlLeftDown=";
   }
   else if(obj.id == "ptzDownID")
   {
       //下
       ptzCtrlCmd="&cPtzControlDown=";
   }
   else if(obj.id == "ptzRightDownID")
   {
       //右下
       ptzCtrlCmd="&cPtzControlRightDown=";
   }
   else if(obj.id == "zoomAddID")
   {
       //Zoom Add
       ptzCtrlCmd="&cPtzControlZoomFar=";
   }
   else if(obj.id == "zoomDecID")
   {
       //Zoom Dec
       ptzCtrlCmd="&cPtzControlZoomNear=";
   }
   else if(obj.id == "focusAddID")
   {
       //Focus Add
       ptzCtrlCmd="&cPtzControlFocusFar=";
   }
   else if(obj.id == "focusDecID")
   {
       //Focus Dec
       ptzCtrlCmd="&cPtzControlFocusNear=";
   }
   else
   {
       //未知ID
       return;
   }
   
   //
   g_bMousePress = true;
   //
   var ptzDataCmd = ptzCtrlCmd + document.getElementById("panTiltSpeedRangeID").value+"-"
                                + document.getElementById("panTiltSpeedRangeID").value+ "-" 
                                + document.getElementById("zoomSpeedRangeID").value;
    var cmd = "Operation=SetDivContent" + ptzDataCmd;
    SendInformation(PageRefDesURL ,cmd ,"focusModeDiv");
}

//云台Home位
function onPtzHomeBtn(event)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    //当前控制命令
    var ptzCtrlCmd="&cPtzControlHome=";

    var ptzDataCmd = ptzCtrlCmd + document.getElementById("panTiltSpeedRangeID").value+"-"
                                + document.getElementById("panTiltSpeedRangeID").value+ "-" 
                                + document.getElementById("zoomSpeedRangeID").value;
    var cmd = "Operation=SetDivContent" + ptzDataCmd;
    SendInformation(PageRefDesURL ,cmd,"focusModeDiv");
}

//云台停止
function onPtzStopBtn(event)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    //
    g_bMousePress = false;
    //
    var ptzDataCmd = "&cPtzControlStop=" + document.getElementById("panTiltSpeedRangeID").value+"-"
                                + document.getElementById("panTiltSpeedRangeID").value+ "-" 
                                + document.getElementById("zoomSpeedRangeID").value;
    var cmd = "Operation=SetDivContent" + ptzDataCmd;
    SendInformation(PageRefDesURL ,cmd,"focusModeDiv");
}

//鼠标移出按钮时需要停止云台
function onPtzStopMouseOut()
{
    //如果鼠标没有按下则返回
    if(!g_bMousePress)
    {
        return;
    }

    //
    g_bMousePress = false;
    //
    var ptzDataCmd = "&cPtzControlStop=" + document.getElementById("panTiltSpeedRangeID").value+"-"
                                         + document.getElementById("panTiltSpeedRangeID").value+ "-" 
                                         + document.getElementById("zoomSpeedRangeID").value;
    var cmd = "Operation=SetDivContent" + ptzDataCmd;
    SendInformation(PageRefDesURL ,cmd,"focusModeDiv");
}

//预置点操作
function setPresetCtrl(iPresetCtrlType,iPresetNum)
{
    if(iPresetNum <0 || iPresetNum >255)
        return;


    var presetCtrlCmd="";
    operateData = "&";    
    switch(iPresetCtrlType)
    {
        case 0:
            {
                //预置点设置
                presetCtrlCmd="&cPtzControlPresetStore=";
                newstatus = "Set";
            }
            break;
        case 1:
            {
                //预置点调用
                presetCtrlCmd="&cPtzControlPresetRecall=";
                newstatus = "Call";
            }
            break;
        case 2:
            {
                //预置点清除
                presetCtrlCmd="&cPtzControlPresetClear=";
                newstatus = "Clear";
            }
            break;
         default:
             return;     
    }
    operateData = operateData+"PtzControlPreset:"+newstatus+"-to-"+iPresetNum+",";
    //
    var presetDataCmd = presetCtrlCmd + iPresetNum;
    var cmd = "Operation=SetDivContent" + presetDataCmd;
    SendInformation(PageRefDesURL ,cmd,"focusModeDiv");

    // var msghead = getHeaderData("LiveView");
    // var str = "begin&Operation=SetOperateLog" + msghead + operateData + "*&SubmitData=end";
    // SendInformation(PageRefDesURL ,str);
}

function onSetPresetNumBtn(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    var iPresetNum = document.getElementById("presetId").value;
    
    if(iPresetNum.length >= 3)
        return;

    var iPutNum = 0;

    //判断当前BtnID
   if(obj.id == "presetNum0ID")
   {
        iPutNum = 0;
   }
   else if(obj.id == "presetNum1ID")
   {
        iPutNum = 1;
   }
   else if(obj.id == "presetNum2ID")
   {
        iPutNum = 2;
   }
   else if(obj.id == "presetNum3ID")
   {
        iPutNum = 3;
   }
   else if(obj.id == "presetNum4ID")
   {
        iPutNum = 4;
   }
   else if(obj.id == "presetNum5ID")
   {
        iPutNum = 5;
   }
   else if(obj.id == "presetNum6ID")
   {
        iPutNum = 6;
   }
   else if(obj.id == "presetNum7ID")
   {
        iPutNum = 7;
   }
   else if(obj.id == "presetNum8ID")
   {
        iPutNum = 8;
   }
   else if(obj.id == "presetNum9ID")
   {
        iPutNum = 9;
   }
   else
   {
       //未知ID
       return;
   }

   document.getElementById("presetId").value = iPresetNum + iPutNum.toString();
}


//预置点Ctrl Click
function onPresetCtrlBtn(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    //当前预置点操作类型
    var iPresetCtrlType=0;

    //当前预置点
    var iPresetNum = document.getElementById("presetId").value;
    if(0 == iPresetNum.length)
        return;

    if(iPresetNum == 999)
    {
        var strSubmData = "begin&Operation=SetDivContent" + "&cPosCorrectShow=" + 1 + "&SubmitData=end";
        SendInformation(PageRefDesURL ,strSubmData);
        Relocate("/fcgi/do?id=1&id=4");
        return;
    }

    if(iPresetNum > 255)
    {
        //等于255
        iPresetNum = 255;
        document.getElementById("presetId").value = 255;
    }

    //判断当前BtnID
   if(obj.id == "presetNumStoreID")
   {
       //预置点设置
       iPresetCtrlType = 0;
       document.getElementById("presetId").value = "";
   }
   else if(obj.id == "presetNumCallID")
   {
       //预置点调用
       iPresetCtrlType = 1;

       //预置点调用后输入框需清除
       document.getElementById("presetId").value = "";
   }
   else
   {
       //未知ID
       return;
   }

   //预置点操作
   setPresetCtrl(iPresetCtrlType,iPresetNum);
}

//Ptz Speed 调整
function onPtzSpeedCtrlBtn(event,obj)
{
    //步长
    var iStep = 1;

    //
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

     //
     var strSubmData = "";
    if(obj.id == "zoomSpeedDecID")
    {
        //Speed Dec
        var iSpeed = parseInt(document.getElementById("zoomSpeedRangeID").value);
        if(iSpeed <= gZoomMinSpeed)
            return;

        iSpeed -= iStep;
        //
        document.getElementById("zoomSpeedRangeID").value = iSpeed;
        //设置滑块当前位置
        setSliderCurPos("zoomSpeedRangeID");

        //数据组装
        strSubmData = "&cPtzControlZoomSpeed=" + iSpeed;
    }
    else if(obj.id == "panTiltSpeedDecID")
    {
        //Speed Dec
        var iSpeed = parseInt(document.getElementById("panTiltSpeedRangeID").value);
        if(iSpeed <= gPanTiltMinSpeed)
            return;

        iSpeed -= iStep;
        //
        document.getElementById("panTiltSpeedRangeID").value = iSpeed;
        //设置滑块当前位置
        setSliderCurPos("panTiltSpeedRangeID");

        //数据组装
        strSubmData = "&cPtzControlPanSpeed=" + iSpeed;
    }
    else if(obj.id == "zoomSpeedAddID")
    {
        //Speed Add
        var iSpeed = parseInt(document.getElementById("zoomSpeedRangeID").value);
        if(iSpeed >= gZoomMaxSpeed)
            return;

        iSpeed += iStep;
        //
        document.getElementById("zoomSpeedRangeID").value = iSpeed;
        //设置滑块当前位置
        setSliderCurPos("zoomSpeedRangeID");

        //数据组装
        strSubmData = "&cPtzControlZoomSpeed=" + iSpeed;
    }
    else if(obj.id == "panTiltSpeedAddID")
    {
        //Speed Add
        var iSpeed = parseInt(document.getElementById("panTiltSpeedRangeID").value);
        if(iSpeed >= gPanTiltMaxSpeed)
            return;

        iSpeed += iStep;
        //
        document.getElementById("panTiltSpeedRangeID").value = iSpeed;
        //设置滑块当前位置
        setSliderCurPos("panTiltSpeedRangeID");

        //数据组装
        strSubmData = "&cPtzControlPanSpeed=" + iSpeed;
    }
    else
    {
        return;
    }
    
    //
    var f3 = document.getElementById("submit_form");
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL ,strSubmData);
}

//Input标签(Type=Range)滑动时的样式
$.fn.RangeSlider = function(cfg){
    this.sliderCfg = {
        min: cfg && !isNaN(parseFloat(cfg.min)) ? Number(cfg.min) : null,
        max: cfg && !isNaN(parseFloat(cfg.max)) ? Number(cfg.max) : null,
        step: cfg && Number(cfg.step) ? cfg.step : 1,
        callback: cfg && cfg.callback ? cfg.callback : null
    };

    var $input = $(this);
    var min = this.sliderCfg.min;
    var max = this.sliderCfg.max;
    var step = this.sliderCfg.step;
    var callback = this.sliderCfg.callback;

    if(parseInt(max)-parseInt(min) <= 0)
        return;

    $input.attr('min', min)
        .attr('max', max)
        .attr('step', step);

    $input.bind("input", function(e){
        $input.attr('value', this.value);
        $input.css('background', 'linear-gradient(to right, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #FFFFFF ' 
                + this.value*100/(max-min) + '%, #FFFFFF)');

        if ($.isFunction(callback)) {
            callback(this);
        }
    });
};

//设置当前滑块位置
function setSliderCurPos(controlId)
{
    //默认值
    let speedVal = 5;
    let speedMinVal = gPanTiltMinSpeed;
    let speedMaxVal = gPanTiltMaxSpeed;

    if(controlId == "zoomSpeedRangeID")
    {
        //Zoom Speed
        speedVal = $('#'+controlId).val();

        speedMinVal = gZoomMinSpeed;
        speedMaxVal = gZoomMaxSpeed;
    }
    else if(controlId == "panTiltSpeedRangeID")
    {
        //Pan Tilt Speed
        speedVal = $('#'+controlId).val();

        speedMinVal = gPanTiltMinSpeed;
        speedMaxVal = gPanTiltMaxSpeed;
    }
    else
    {
        return;
    }

    $('#'+controlId).css('background', 'linear-gradient(to right, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #01E2FF, #FFFFFF ' 
                + speedVal*100/(speedMaxVal-speedMinVal) + '%, #FFFFFF)');
}

//滑块Change事件
function onSliderValChangeEvent(obj)
{
    //
    let strSubmData = "";
    if(obj.id == "zoomSpeedRangeID")
    {
        //数据组装
        strSubmData = "&cPtzControlZoomSpeed=" + obj.value;
    }
    else if(obj.id == "panTiltSpeedRangeID")
    {
        //数据组装
        strSubmData = "&cPtzControlPanSpeed=" + obj.value;
    }
    else
    {
        return;
    }
    
    //
    var f3 = document.getElementById("submit_form");
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL ,strSubmData);
}


//设置当前Mode
function setFocusMode(curMode)
{
    focusMode = curMode;
    if(curMode == focus_manual)
    {
        //手动
        $("#afSwitchBtnId").css('background','url(../images/MainView/Ptz/MF_n.png) no-repeat');

        //设置Focus按钮可选
        document.getElementById("focusAddID").disabled = false;
        document.getElementById("focusDecID").disabled = false;

        //更改字体颜色
        $("#focusAddLabelId").css('color',g_normalFontCol);
        $("#focusDecLabelId").css('color',g_normalFontCol);

        /**************Camera Ctrl Focus**************/
        //AF Sensitivity MF Disable
        document.getElementById("afSensitivitiesId").disabled = true;
        document.getElementById("afFrameId").disabled = true;

        //
        document.getElementById("ptzAssistSwitchBtnId").disabled = false;
        setSwitchBtnState("ptzAssistSwitchBtnId");

        $("#afSensitivitiesLabId").css('color',g_disableFontCol);
        $("#afFrameLabId").css('color',g_disableFontCol);
        $("#ptzAssistLabId").css('color',g_normalFontCol);

    }
    else if(curMode == focus_auto)
    {
        //自动
        $("#afSwitchBtnId").css('background','url(../images/MainView/Ptz/AF_n.png) no-repeat');

        //设置Focus按钮不可操作
        document.getElementById("focusAddID").disabled = true;
        document.getElementById("focusDecID").disabled = true;

        //更改字体颜色
        $("#focusAddLabelId").css('color',g_disableFontCol);
        $("#focusDecLabelId").css('color',g_disableFontCol);

        /**************Camera Ctrl Focus**************/
        document.getElementById("afSensitivitiesId").disabled = false;
        document.getElementById("afFrameId").disabled = false;

        document.getElementById("ptzAssistSwitchBtnId").disabled = true;

        $("#afSensitivitiesLabId").css('color',g_normalFontCol);
        $("#afFrameLabId").css('color',g_normalFontCol);
        $("#ptzAssistLabId").css('color',g_disableFontCol);
    }
}

function onFocusModeSwitchBtn(event)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    if(focusMode == focus_manual)
    {
        focusMode = focus_auto;
    }
    else if(focusMode == focus_auto)
    {
        focusMode = focus_manual;
    }
    else
    {
        return;
    }

    //当前控制命令
    var ptzCtrlCmd="&cPtzControlFocusMode=";

    var ptzDataCmd = ptzCtrlCmd + focusMode;
    var cmd = "Operation=SetDivContent" + ptzDataCmd;
    SendInformation(PageRefDesURL ,cmd);

    //
    setFocusMode(focusMode);
}

// 命令反馈
function OnFindDivVarAction(hcDivVar, divVar)
{
    if(hcDivVar == "hcfocusModeDiv")
    {
        if(focusMode != divVar && (divVar == "0" || divVar == "1"))
        {
            setFocusMode(divVar);
        }
    }

    if(hcDivVar == "hcgeneralDiv")
    {

        //格式 7/3/4/5 ; Brightness/Gamma/Saturation/Hue
        //alert("var="+divVar);
        //console.log("paramList Length="+paramList.length);

        //解析
        let paramList = divVar.split("/"); 
        if(paramList.length < 5)
            return;

        let paramArry = [];
        for(var i=0;i<paramList.length;i++)
        {
            paramArry[i] = paramList[i];
        }

        document.getElementById("brightnessInputID").value = TransEmptyStrTo0(paramArry[0]);
        document.getElementById("gammaInputID").value = TransEmptyStrTo0(paramArry[1]);
        document.getElementById("saturateInputID").value = TransEmptyStrTo0(paramArry[2]);
        document.getElementById("hueInputID").value = TransEmptyStrTo0(paramArry[3]);
        document.getElementById("sharpInputID").value = TransEmptyStrTo0(paramArry[4]);
    }
}

//设置用户权限
function  setUserPermission(curPerm)
{
    userPerm = curPerm;
    if(curPerm == "2")
    {
        /*****Viewer*****/
        //Ptz Ctrl
        $("#cameraCtrlDivId").hide();
        //Camera Ctrl
        $("#cameraSettingsDivId").hide();
        //视频最大化按钮
        $("#videoWndMaxID").hide();
    }
    else if(curPerm == "1")
    {
        /*****Operator*****/

        //Picture
        $("#pictureSetTabId").hide();
    }
}

/********************************************************************************/
/********************************Camera Settings*********************************/
/********************************************************************************/
// 模块切换
function onTabChangeBtn(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    if(curModule == obj.id)
        return;


    setModuleHide();
    setModuleShow(obj.id);
}

//设置模块隐藏
function setModuleHide()
{
    if(curModule.length <= 0)
        return;


    var borderBottomType = "1px solid #89CFD8";
    var backgroundColor = "#000000";
    if(curModule == "epSetTabId")
    {
        //曝光
        $("#epSettingsDivId").hide();

        $("#epSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
    }
    else if(curModule == "wbSetTabId")
   {
        //白平衡
        $("#wbSettingsDivId").hide();

        $("#wbSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
   }
   else if(curModule == "fcSetTabId")
   {
       //对焦
       $("#fcSettingsDivId").hide();

       $("#fcSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
   }
   else if(curModule == "mrSetTabId")
   {
       //镜像
       $("#mrSettingsDivId").hide();

       $("#mrSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
   }
   else if(curModule == "panTiltSetTabId")
   {
       //水平 倾斜 变焦
       $("#panTiltSettingsDivId").hide();

       $("#panTiltSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
   }
   else if(curModule == "pictureSetTabId")
   {
       //图像
       $("#imageSettingsDivId").hide();

       $("#pictureSetTabId").css({"border-bottom":borderBottomType,"background":backgroundColor});
   }
}


// 设置模块显示
function setModuleShow(curId)
{
    //判断当前ID
    var borderBottomType = "0px";
    //渐变颜色
    var lineGradientColor = "linear-gradient(182.18deg, rgba(88, 86, 86, 0.72) -35.81%,"+
                            "rgba(112, 112, 112, 0.62) 33.32%, rgba(0, 0, 0, 1) 98.26%, rgba(0, 0, 0, 0) 98.26%)";
    if(curId == "epSetTabId")
   {
        //曝光
        $("#epSettingsDivId").show();

        $("#epSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }
   else if(curId == "wbSetTabId")
   {
        //白平衡
        $("#wbSettingsDivId").show();

        $("#wbSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }
   else if(curId == "fcSetTabId")
   {
       //对焦
       $("#fcSettingsDivId").show();

       $("#fcSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }
   else if(curId == "mrSetTabId")
   {
       //镜像
       $("#mrSettingsDivId").show();

       $("#mrSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }
   else if(curId == "panTiltSetTabId")
   {
       //水平 倾斜 变焦
       $("#panTiltSettingsDivId").show();

       $("#panTiltSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }
   else if(curId == "pictureSetTabId")
   {
       //图像
       $("#imageSettingsDivId").show();

       $("#pictureSetTabId").css({"border-bottom":borderBottomType,"background":lineGradientColor});
   }

   curModule = curId;
}

function onSelectChange(obj)
{
    var strSubmData = "";
    if(obj.id == "epModeId")
    {
        //曝光模式
        strSubmData = "&cImageExposureMode=" + obj.value;

        //
        setExposureMode($('option:selected','#epModeId').index());
    }
    else if(obj.id == "wdrsId")
    {
        //WDR Mode
        strSubmData = "&cImageExposureWDR=" + obj.value;
    }
    else if(obj.id == "wbModeId")
    {
        //白平衡模式
        strSubmData = "&cImageWhileMode=" + obj.value;

        //
        setWhileMode(obj.value);
    }
    else if(obj.id == "afSensitivitiesId")
    {
        //AF Sensitivity
        strSubmData = "&cImageFocusSensitivity=" + obj.value;
    }
    else if(obj.id == "afFrameId")
    {
        //AF Frame
        strSubmData = "&cImageFocusAFFrame=" + obj.value;
    }
    else if(obj.id == "presetSpeedId")
    {
        //Preset Speed
        strSubmData = "&cPtzPresetSpeed=" + obj.value;
    }
    else if(obj.id == "initialPosId")
    {
        //Initial Position
        strSubmData = "&cPtzInitialPosition=" + obj.value;
    }
    else if(obj.id == "dZoomLimId")
    {
        //D-Zoom Limit
        strSubmData = "&cPtzDZoomLimit=" + obj.value;
    }
    else if(obj.id == "2dNRSelId")
    {
        //2d NR
        strSubmData = "&cImage2DNR=" + obj.value;
    }
    else if(obj.id == "3dNRSelId")
    {
        //3d NR
        strSubmData = "&cImage3DNR=" + obj.value;
    }
    else if(obj.id == "imageModeSelId")
    {
        //Image Mode
        strSubmData = "&cImageMode=" + obj.value;

        //
        setImageMode(obj.value);
    }
    else if(obj.id == "antiFlickerModeId")
    {
        //Anti-Flicke
        console.log("asdasfs11 %d",obj.value);
        strSubmData = "&cAntiFlickerMode=" + obj.value;
    }
    var f3 = document.getElementById("submit_form");
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL ,strSubmData);
}

function onInputValAdjustBtn(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    const iMinEpCompLvl = -6;
    const iMaxEpCompLvl = 4;

    const iMinManualRed = 0;
    const iMaxManualRed = 127;

    const iMinManualBlue = 0;
    const iMaxManualBlue = 127;
    //////////////////////////////////////////
    const iMinGamma = 0;
    const iMaxGamma = 3;

    const iMinVal1 = 0;
    const iMaxVal1 = 15;

    const iMinVal2 = 0;
    const iMaxVal2 = 14;

    var strSubmData = "";
    if(obj.id == "gainDecId")
    {
        if(curGainIndex <=0)
            return;

        curGainIndex -= 1;
        document.getElementById("gainInputId").value = gainParamArr[curGainIndex];

        //数据组装
        strSubmData = "&cImageExposureGain=" + gainParamVal[curGainIndex];
    }
    else if(obj.id == "gainAddId")
    {
        if(curGainIndex >= gainParamArr.length-1)
            return;

        curGainIndex += 1;
        document.getElementById("gainInputId").value = gainParamArr[curGainIndex];

        //数据组装
        strSubmData = "&cImageExposureGain=" + gainParamVal[curGainIndex];
    }
    else if(obj.id == "gainLimitDecId")
    {
        if(curGainLimitIndex <=0)
            return;

        curGainLimitIndex -= 1;
        document.getElementById("gainLimitInputId").value = gainLimitArr[curGainLimitIndex];

        //数据组装
        strSubmData = "&cImageExposureGainLimit=" + gainLimitVal[curGainLimitIndex];
    }
    else if(obj.id == "gainLimitAddId")
    {
        if(curGainLimitIndex >= gainLimitArr.length-1)
            return;

        curGainLimitIndex += 1;
        document.getElementById("gainLimitInputId").value = gainLimitArr[curGainLimitIndex];

        //数据组装
        strSubmData = "&cImageExposureGainLimit=" + gainLimitVal[curGainLimitIndex];
    }
    else if(obj.id == "irisDecId")
    {
        if(curIrisIndex <=0)
            return;

        curIrisIndex -= 1;
        document.getElementById("irisInputId").value = irisParamArr[curIrisIndex];

        //数据组装
        strSubmData = "&cImageExposureIris=" + irisParamVal[curIrisIndex];
    }
    else if(obj.id == "irisAddId")
    {
        if(curIrisIndex >= irisParamArr.length-1)
            return;

        curIrisIndex += 1;
        document.getElementById("irisInputId").value = irisParamArr[curIrisIndex];

        //数据组装
        strSubmData = "&cImageExposureIris=" + irisParamVal[curIrisIndex];
    }
    else if(obj.id == "shutterSpeedDecId")
    {
        if(curShutterSpeedIndex <=0)
            return;

        curShutterSpeedIndex -= 1;

        if("30" == gCurFrameRate)
        {
            document.getElementById("shutterSpeedInputId").value = shutterSpeedParamArr[curShutterSpeedIndex];
        }
        else if("25" == gCurFrameRate)
        {
            document.getElementById("shutterSpeedInputId").value = shutterSpeedParam25Arr[curShutterSpeedIndex];
        }

        //数据组装
        strSubmData = "&cImageExposureShutter=" + shutterSpeedParamVal[curShutterSpeedIndex];
    }
    else if(obj.id == "shutterSpeedAddId")
    {
        if(curShutterSpeedIndex >= shutterSpeedParamArr.length-1)
            return;

        curShutterSpeedIndex += 1;

        if("30" == gCurFrameRate)
        {
            document.getElementById("shutterSpeedInputId").value = shutterSpeedParamArr[curShutterSpeedIndex];
        }
        else if("25" == gCurFrameRate)
        {
            document.getElementById("shutterSpeedInputId").value = shutterSpeedParam25Arr[curShutterSpeedIndex];
        }

        //数据组装
        strSubmData = "&cImageExposureShutter=" + shutterSpeedParamVal[curShutterSpeedIndex];
    }
    else if(obj.id == "epCompLvlDecId")
    {
        var iEpCompLvlVal = parseInt(document.getElementById("epCompLvlInputId").value);
        if(iEpCompLvlVal <= iMinEpCompLvl)
            return;

        iEpCompLvlVal -= 1;
        //
        document.getElementById("epCompLvlInputId").value = iEpCompLvlVal;

        //数据组装
        strSubmData = "&cImageExposureLevel=" + iEpCompLvlVal;
    }
    else if(obj.id == "epCompLvlAddId")
    {
        var iEpCompLvlVal = parseInt(document.getElementById("epCompLvlInputId").value);
        if(iEpCompLvlVal >= iMaxEpCompLvl)
            return;

        iEpCompLvlVal += 1;
        //
        document.getElementById("epCompLvlInputId").value = iEpCompLvlVal;

        //数据组装
        strSubmData = "&cImageExposureLevel=" + iEpCompLvlVal;
    }
    else if(obj.id == "manualRedDecID")
    {
        var iManualRedVal = parseInt(document.getElementById("manualRedInputID").value);
        if(iManualRedVal <= iMinManualRed)
            return;

        iManualRedVal -= 1;
        //
        document.getElementById("manualRedInputID").value = iManualRedVal;

        //数据组装
        strSubmData = "&cImageWhileManualRed=" + iManualRedVal;
    }
    else if(obj.id == "manualRedAddID")
    {
        var iManualRedVal = parseInt(document.getElementById("manualRedInputID").value);
        if(iManualRedVal >= iMaxManualRed)
            return;

        iManualRedVal += 1;
        //
        document.getElementById("manualRedInputID").value = iManualRedVal;

        //数据组装
        strSubmData = "&cImageWhileManualRed=" + iManualRedVal;
    }
    else if(obj.id == "manualBlueDecID")
    {
        var iManualBlueVal = parseInt(document.getElementById("manualBlueInputID").value);
        if(iManualBlueVal <= iMinManualBlue)
            return;

        iManualBlueVal -= 1;
        //
        document.getElementById("manualBlueInputID").value = iManualBlueVal;

        //数据组装
        strSubmData = "&cImageWhileManualBlue=" + iManualBlueVal;
    }
    else if(obj.id == "manualBlueAddID")
    {
        var iManualBlueVal = parseInt(document.getElementById("manualBlueInputID").value);
        if(iManualBlueVal >= iMaxManualBlue)
            return;

        iManualBlueVal += 1;
        //
        document.getElementById("manualBlueInputID").value = iManualBlueVal;

        //数据组装
        strSubmData = "&cImageWhileManualBlue=" + iManualBlueVal;
    }
    else if(obj.id == "tiltUpLimitDecBtnId")
    {
        const iMinTiltUpLimitVal = 0;
        const iMaxTiltUpLimitVal = 90;
        
        //有效值判断
        let inputVal = document.getElementById("tiltUpLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinTiltUpLimitVal || inputVal > iMaxTiltUpLimitVal)
        {
            document.getElementById("tiltUpLimitInputId").value = g_iTiltUpLimVal;
            return;
        }
        //
        var iTiltUpLimitVal = parseInt(inputVal);
        if(iTiltUpLimitVal <= iMinTiltUpLimitVal)
            return;

        iTiltUpLimitVal -= 1;
        //
        document.getElementById("tiltUpLimitInputId").value = iTiltUpLimitVal;

        //数据组装
        strSubmData = "&cPtzUpLimit=" + iTiltUpLimitVal;

        //保存数据
        g_iTiltUpLimVal = iTiltUpLimitVal;
    }
    else if(obj.id == "tiltUpLimitAddBtnId")
    {
        const iMinTiltUpLimitVal = 0;
        const iMaxTiltUpLimitVal = 90;
        
        //有效值判断
        let inputVal = document.getElementById("tiltUpLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinTiltUpLimitVal || inputVal > iMaxTiltUpLimitVal)
        {
            document.getElementById("tiltUpLimitInputId").value = g_iTiltUpLimVal;
            return;
        }
        //
        var iTiltUpLimitVal = parseInt(inputVal);
        if(iTiltUpLimitVal >= iMaxTiltUpLimitVal)
            return;

        iTiltUpLimitVal += 1;
        //
        document.getElementById("tiltUpLimitInputId").value = iTiltUpLimitVal;

        //数据组装
        strSubmData = "&cPtzUpLimit=" + iTiltUpLimitVal;

        //保存数据
        g_iTiltUpLimVal = iTiltUpLimitVal;
    }

    else if(obj.id == "tiltDownLimitDecBtnId")
    {
        const iMinTiltDownLimitVal = -30;
        const iMaxTiltDownLimitVal = 0;
        
        //有效值判断
        let inputVal = document.getElementById("tiltDownLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinTiltDownLimitVal || inputVal > iMaxTiltDownLimitVal)
        {
            document.getElementById("tiltDownLimitInputId").value = g_iTiltDownLimVal;
            return;
        }
        //
        var iTiltDownLimitVal = parseInt(inputVal);
        if(iTiltDownLimitVal <= iMinTiltDownLimitVal)
            return;

        iTiltDownLimitVal -= 1;
        //
        document.getElementById("tiltDownLimitInputId").value = iTiltDownLimitVal;

        //数据组装
        strSubmData = "&cPtzDownLimit=" + iTiltDownLimitVal;

        //保存数据
        g_iTiltDownLimVal = iTiltDownLimitVal;
    }
    else if(obj.id == "tiltDownLimitAddBtnId")
    {
        const iMinTiltDownLimitVal = -30;
        const iMaxTiltDownLimitVal = 0;
        
        //有效值判断
        let inputVal = document.getElementById("tiltDownLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinTiltDownLimitVal || inputVal > iMaxTiltDownLimitVal)
        {
            document.getElementById("tiltDownLimitInputId").value = g_iTiltDownLimVal;
            return;
        }
        //
        var iTiltDownLimitVal = parseInt(inputVal);
        if(iTiltDownLimitVal >= iMaxTiltDownLimitVal)
            return;

        iTiltDownLimitVal += 1;
        //
        document.getElementById("tiltDownLimitInputId").value = iTiltDownLimitVal;

        //数据组装
        strSubmData = "&cPtzDownLimit=" + iTiltDownLimitVal;

        //保存数据
        g_iTiltDownLimVal = iTiltDownLimitVal;
    }
    else if(obj.id == "panLeftLimitDecBtnId")
    {
        const iMinPanLeftLimitVal = -170;
        const iMaxPanLeftLimitVal = 0;

        //有效值判断
        let inputVal = document.getElementById("panLeftLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinPanLeftLimitVal || inputVal > iMaxPanLeftLimitVal)
        {
            document.getElementById("panLeftLimitInputId").value = g_iPanLeftLimVal;
            return;
        }
        //
        var iPanLeftLimitVal = parseInt(inputVal);
        if(iPanLeftLimitVal <= iMinPanLeftLimitVal)
            return;

        iPanLeftLimitVal -= 1;
        //
        document.getElementById("panLeftLimitInputId").value = iPanLeftLimitVal;

        //数据组装
        strSubmData = "&cPtzLeftLimit=" + iPanLeftLimitVal;

        //保存数据
        g_iPanLeftLimVal = iPanLeftLimitVal;
    }
    else if(obj.id == "panLeftLimitAddBtnId")
    {
        const iMinPanLeftLimitVal = -170;
        const iMaxPanLeftLimitVal = 0;
        
        //有效值判断
        let inputVal = document.getElementById("panLeftLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinPanLeftLimitVal || inputVal > iMaxPanLeftLimitVal)
        {
            document.getElementById("panLeftLimitInputId").value = g_iPanLeftLimVal;
            return;
        }
        //
        var iPanLeftLimitVal = parseInt(inputVal);
        if(iPanLeftLimitVal >= iMaxPanLeftLimitVal)
            return;

        iPanLeftLimitVal += 1;
        //
        document.getElementById("panLeftLimitInputId").value = iPanLeftLimitVal;

        //数据组装
        strSubmData = "&cPtzLeftLimit=" + iPanLeftLimitVal;

        //保存数据
        g_iPanLeftLimVal = iPanLeftLimitVal;
    }
    else if(obj.id == "panRightLimitDecBtnId")
    {
        const iMinPanRightLimitVal = 0;
        const iMaxPanRightLimitVal = 170;
        
        //有效值判断
        let inputVal = document.getElementById("panRightLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinPanRightLimitVal || inputVal > iMaxPanRightLimitVal)
        {
            document.getElementById("panRightLimitInputId").value = g_iPanRightLimVal;
            return;
        }
        //
        var iPanRightLimitVal = parseInt(inputVal);
        if(iPanRightLimitVal <= iMinPanRightLimitVal)
            return;

            iPanRightLimitVal -= 1;
        //
        document.getElementById("panRightLimitInputId").value = iPanRightLimitVal;

        //数据组装
        strSubmData = "&cPtzRightLimit=" + iPanRightLimitVal;

        //保存数据
        g_iPanRightLimVal = iPanRightLimitVal;
    }
    else if(obj.id == "panRightLimitAddBtnId")
    {
        const iMinPanRightLimitVal = 0;
        const iMaxPanRightLimitVal = 170;
        
        //有效值判断
        let inputVal = document.getElementById("panRightLimitInputId").value;
        if(isNaN(inputVal) || inputVal.length == 0 || inputVal < iMinPanRightLimitVal || inputVal > iMaxPanRightLimitVal)
        {
            document.getElementById("panRightLimitInputId").value = g_iPanRightLimVal;
            return;
        }
        //
        var iPanRightLimitVal = parseInt(inputVal);
        if(iPanRightLimitVal >= iMaxPanRightLimitVal)
            return;

        iPanRightLimitVal += 1;
        //
        document.getElementById("panRightLimitInputId").value = iPanRightLimitVal;

        //数据组装
        strSubmData = "&cPtzRightLimit=" + iPanRightLimitVal;

        //保存数据
        g_iPanRightLimVal = iPanRightLimitVal;
    }
    else if(obj.id == "gammaDecID")
    {
        var iGammaVal = parseInt(document.getElementById("gammaInputID").value);
        if(iGammaVal <= iMinGamma)
            return;

        iGammaVal -= 1;
        //
        document.getElementById("gammaInputID").value = iGammaVal;

        //数据组装
        strSubmData = "&cImageGamma=" + iGammaVal;
    }
    else if(obj.id == "gammaAddID")
    {
        var iGammaVal = parseInt(document.getElementById("gammaInputID").value);
        if(iGammaVal >= iMaxGamma)
            return;

        iGammaVal += 1;
        //
        document.getElementById("gammaInputID").value = iGammaVal;

        //数据组装
        strSubmData = "&cImageGamma=" + iGammaVal;
    }
    else if(obj.id == "brightnessDecID")
    {
        var iBrightnessVal = parseInt(document.getElementById("brightnessInputID").value);
        if(iBrightnessVal <= iMinVal1)
            return;

        iBrightnessVal -= 1;
        //
        document.getElementById("brightnessInputID").value = iBrightnessVal;

        //数据组装
        strSubmData = "&cImageBrightness=" + iBrightnessVal;
    }
    else if(obj.id == "brightnessAddID")
    {
        var iBrightnessVal = parseInt(document.getElementById("brightnessInputID").value);
        if(iBrightnessVal >= iMaxVal1)
            return;

        iBrightnessVal += 1;
        //
        document.getElementById("brightnessInputID").value = iBrightnessVal;

        //数据组装
        strSubmData = "&cImageBrightness=" + iBrightnessVal;
    }
    else if(obj.id == "hueDecID")
    {
        var ihueVal = parseInt(document.getElementById("hueInputID").value);
        if(ihueVal <= iMinVal1)
            return;

        ihueVal -= 1;
        //
        document.getElementById("hueInputID").value = ihueVal;

        //数据组装
        strSubmData = "&cImageHue=" + ihueVal;
    }
    else if(obj.id == "hueAddID")
    {
        var ihueVal = parseInt(document.getElementById("hueInputID").value);
        if(ihueVal >= iMaxVal1)
            return;

        ihueVal += 1;
        //
        document.getElementById("hueInputID").value = ihueVal;

        //数据组装
        strSubmData = "&cImageHue=" + ihueVal;
    }
    else if(obj.id == "saturateDecID")
    {
        var iSaturateVal = parseInt(document.getElementById("saturateInputID").value);
        if(iSaturateVal <= iMinVal1)
            return;

        iSaturateVal -= 1;
        //
        document.getElementById("saturateInputID").value = iSaturateVal;

        //数据组装
        strSubmData = "&cImageSaturation=" + iSaturateVal;
    }
    else if(obj.id == "saturateAddID")
    {
        var iSaturateVal = parseInt(document.getElementById("saturateInputID").value);
        if(iSaturateVal >= iMaxVal1)
            return;

        iSaturateVal += 1;
        //
        document.getElementById("saturateInputID").value = iSaturateVal;

        //数据组装
        strSubmData = "&cImageSaturation=" + iSaturateVal;
    }
    else if(obj.id == "sharpDecID")
    {
        var iSharpVal = parseInt(document.getElementById("sharpInputID").value);
        if(iSharpVal <= iMinVal2)
            return;

        iSharpVal -= 1;
        //
        document.getElementById("sharpInputID").value = iSharpVal;

        //数据组装
        strSubmData = "&cImageSharpness=" + iSharpVal;
    }
    else if(obj.id == "sharpAddID")
    {
        var iSharpVal = parseInt(document.getElementById("sharpInputID").value);
        if(iSharpVal >= iMaxVal2)
            return;

        iSharpVal += 1;
        //
        document.getElementById("sharpInputID").value = iSharpVal;

        //数据组装
        strSubmData = "&cImageSharpness=" + iSharpVal;
    }

    var f3 = document.getElementById("submit_form");
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL ,strSubmData);
}

    // input key
function onInputKeyDown(event,obj)
{
    if(event.keyCode==13)
    {
        //Enter
        if(isNaN(obj.value) || obj.value.length == 0)//检查其参数是否是非数字值
        {
            //非数字值时,替换上次保存的Value
            let iValue = 0;
            if(obj.id == "tiltUpLimitInputId")
            {
                iValue = g_iTiltUpLimVal;
            }
            else if(obj.id == "panLeftLimitInputId")
            {
                iValue = g_iPanLeftLimVal;
            }
            else if(obj.id == "panRightLimitInputId")
            {
                iValue = g_iPanRightLimVal;
            }
            else if(obj.id == "tiltDownLimitInputId")
            {
                iValue = g_iTiltDownLimVal;
            }
            else
            {
                return;
            }

            document.getElementById(obj.id).value = iValue;
        }
        else
        {
            //数字值
            var strSubmData = "";
            let iValue = document.getElementById(obj.id).value;
            if(obj.id == "tiltUpLimitInputId")
            {
                if(iValue == g_iTiltUpLimVal)
                    return;
                
                let iMinTiltUpLimitVal = 0;
                let iMaxTiltUpLimitVal = 90;
                if(iValue < iMinTiltUpLimitVal || iValue > iMaxTiltUpLimitVal)
                {
                    document.getElementById(obj.id).value = g_iTiltUpLimVal;
                    return;
                }

                g_iTiltUpLimVal = iValue;
                strSubmData = "&cPtzUpLimit=" + iValue;
                
            }
            else if(obj.id == "panLeftLimitInputId")
            {
                if(iValue == g_iPanLeftLimVal)
                    return;

                let iMinPanLeftLimitVal = -170;
                let iMaxPanLeftLimitVal = 0;
                if(iValue < iMinPanLeftLimitVal || iValue > iMaxPanLeftLimitVal)
                {
                    document.getElementById(obj.id).value = g_iPanLeftLimVal;
                    return;
                }

                g_iPanLeftLimVal = iValue;
                strSubmData = "&cPtzLeftLimit=" + iValue;
            }
            else if(obj.id == "panRightLimitInputId")
            {
                if(iValue == g_iPanRightLimVal)
                    return;

                let iMinPanRightLimitVal = 0;
                let iMaxPanRightLimitVal = 170;
                if(iValue < iMinPanRightLimitVal || iValue > iMaxPanRightLimitVal)
                {
                    document.getElementById(obj.id).value = g_iPanRightLimVal;
                    return;
                }

                g_iPanRightLimVal = iValue;
                strSubmData = "&cPtzRightLimit=" + iValue;
            }
            else if(obj.id == "tiltDownLimitInputId")
            {
                if(iValue == g_iTiltDownLimVal)
                    return;

                let iMinTiltDownLimitVal = -30;
                let iMaxTiltDownLimitVal = 0;
                if(iValue < iMinTiltDownLimitVal || iValue > iMaxTiltDownLimitVal)
                {
                    document.getElementById(obj.id).value = g_iTiltDownLimVal;
                    return;
                }

                g_iTiltDownLimVal = iValue;
                strSubmData = "&cPtzDownLimit=" + iValue;
            }
            else
            {
                return;
            }

            var f3 = document.getElementById("submit_form");
            strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
            SendInformation(PageRefDesURL ,strSubmData);
        }
    }
}

function onOnePushClick(event)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    showConfirmationModal(msgTitleLang,onePushWBMsgLang,curry(SendInformation,PageRefDesURL,"Operation=GetDivContent&DivName=divWBOnePush"), null, true);
}

function onSwitchBtnClick(event,obj)
{
    var btnType = event.button;
    //如果不是左键则返回
    if(0 != btnType)
    {
        return;
    }

    var strSubmData = "";
    if(obj.id == "ptzAssistSwitchBtnId")
    {
        var switchVal = $("#ptzAssistSwitchBtnId").val();
        switchVal = "0" == switchVal?"1":"0";
        $("#ptzAssistSwitchBtnId").val(switchVal);

        strSubmData = "&cImageFocusPTZAssist=" + switchVal;
    }
    else if(obj.id == "mirrorSwitchBtnId")
    {
        var switchVal = $("#mirrorSwitchBtnId").val();
        switchVal = "0" == switchVal?1:0;
        $("#mirrorSwitchBtnId").val(switchVal);

        //
        var switchVal1 = $("#flipSwitchBtnId").val();
        switchVal1 = "0" == switchVal1?0:2;

        switchVal+=switchVal1;

        strSubmData = "&cImageMirror=" + switchVal;
    }
    else if(obj.id == "flipSwitchBtnId")
    {
        var switchVal = $("#flipSwitchBtnId").val();
        switchVal = "0" == switchVal?2:0;
        $("#flipSwitchBtnId").val(switchVal);

        //
        var switchVal1 = $("#mirrorSwitchBtnId").val();
        switchVal1 = "0" == switchVal1?0:1;

        switchVal+=switchVal1;

        strSubmData = "&cImageMirror=" + switchVal;
    }
    else if(obj.id == "panTiltLimSwitchBtnId")
    {

        var switchVal = $("#panTiltLimSwitchBtnId").val();
        switchVal = "0" == switchVal?1:0;
        $("#panTiltLimSwitchBtnId").val(switchVal);

        strSubmData = "&cPtzLimitEnable=" +switchVal;

        //
        setPanTiltLimMode(switchVal);
    }
    else if(obj.id == "ptzSpeedCompSwitchBtnId")
    {
        var switchVal = $("#ptzSpeedCompSwitchBtnId").val();
        switchVal = "0" == switchVal?"1":"0";
        $("#ptzSpeedCompSwitchBtnId").val(switchVal);

        strSubmData = "&cPtzSpeedComp=" + switchVal;
    }
    else if(obj.id == "motionlessPresetSwitchBtnId")
    {
        var switchVal = $("#motionlessPresetSwitchBtnId").val();
        switchVal = "0" == switchVal?"1":"0";
        $("#motionlessPresetSwitchBtnId").val(switchVal);

        strSubmData = "&cPtzMotionlessPreset=" +switchVal;
    }
    else
    {
        return;
    }

    //设置Switch按钮状态
    setSwitchBtnState(obj.id);
    //
    var f3 = document.getElementById("submit_form");
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL ,strSubmData);
}

function setSwitchBtnState(objID)
{
    var tmpID = "#"+objID;

    var switchVal = $(tmpID).val();
    if("0" == switchVal)
    {
        $(tmpID).css('background','url(../images/switch_off.png) no-repeat');
    }
    else
    {
        $(tmpID).css('background','url(../images/switch_on.png) no-repeat');
    }
}

//自动跟踪 开关
var m_AutoTrackBtnSelected = false;

function onAutoTrackBtn(event) {
    var btnType = event.button;
    //如果不是左键则返回
    if (0 != btnType) {
        return;
    }
    var strSubmData = "";
    if (m_AutoTrackBtnSelected) {
        m_AutoTrackBtnSelected = false;
    } else {
        m_AutoTrackBtnSelected = true;
    }
    setTrackStyle(m_AutoTrackBtnSelected);
    strSubmData = "&cAutoTrackingStatus=" + ((m_AutoTrackBtnSelected == true) ? 1 : 0);
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL, strSubmData);
}

function onTrackMouseOver(obj) {
    if(document.getElementById("autoTrackBtnId").disabled == true)
    {
        return;
    }
    if (!m_AutoTrackBtnSelected) {
        setTrackStyle(true);
    }
}

function onTrackMouseOut(obj) {
    if(document.getElementById("autoTrackBtnId").disabled == true)
    {
        return;
    }
    if (!m_AutoTrackBtnSelected) {
        setTrackStyle(false);
    }
}

function setTrackStyle(bSelect) {
    var imgCSS;
    if (bSelect) {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_hover.png) no-repeat';
    }
    else {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_normal.png) no-repeat';
    }
    $("#autoTrackBtnId").css('background', imgCSS);
}

//自动取景 开关
var m_OnAutoFramBtnSelected = false;
function onAutoFramBtn(event) {
    var btnType = event.button;
    //如果不是左键则返回
    if (0 != btnType) {
        return;
    }
    var strSubmData = "";
    if (m_OnAutoFramBtnSelected) {
        m_OnAutoFramBtnSelected = false;
    } else {
        m_OnAutoFramBtnSelected = true;
    }
    setFramStyle(m_OnAutoFramBtnSelected);
    strSubmData = "&cAutoFramingStatus=" + ((m_OnAutoFramBtnSelected == true) ? 1 : 0);
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL, strSubmData);  
}

function onFramMouseOver(obj) {
    if(document.getElementById("autoFramBtnId").disabled == true)
    {
        return;
    }
    if (!m_OnAutoFramBtnSelected) {
        setFramStyle(true);
    }
}

function onFramMouseOut(obj) {
    if(document.getElementById("autoFramBtnId").disabled == true)
    {
        return;
    }
    if (!m_OnAutoFramBtnSelected) {
        setFramStyle(false);
    }  
}

function setFramStyle(bSelect) {
    var imgCSS;
    if (bSelect) {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_hover.png) no-repeat';
    }
    else {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_normal.png) no-repeat';
    }
    $("#autoFramBtnId").css('background', imgCSS);
}

function setTrackingDefValue() {
    var f2 = document.forms["hiddenValForm"];

    if (parseInt(f2.hcTrackingModecurvalue.value) == 3 || parseInt(f2.hcTrackingModecurvalue.value) == 4)
    {
        document.getElementById("autoTrackBtnId").disabled = true;
        document.getElementById("autoFramBtnId").disabled = false;
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_disable.png) no-repeat';
        $("#autoTrackBtnId").css('background', imgCSS);
        
        if (parseInt(f2.hcAutoTrackingStatus.value) == 1) {//自动取景功能开启
            m_OnAutoFramBtnSelected = true;
            setFramStyle(m_OnAutoFramBtnSelected);
        }
    }
    else if(parseInt(f2.hcTrackingModecurvalue.value) == 5)
    {
        document.getElementById("autoTrackBtnId").disabled = true;
        document.getElementById("autoFramBtnId").disabled = true;
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_disable.png) no-repeat';
        $("#autoFramBtnId").css('background', imgCSS);
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_disable.png) no-repeat';
        $("#autoTrackBtnId").css('background', imgCSS);
    }
    else
    {
        document.getElementById("autoFramBtnId").disabled = true;
        document.getElementById("autoTrackBtnId").disabled = false;
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_disable.png) no-repeat';
        $("#autoFramBtnId").css('background', imgCSS);
        
        if (parseInt(f2.hcAutoTrackingStatus.value) == 1) {//自动跟踪功能开启
            m_AutoTrackBtnSelected = true;
            setTrackStyle(m_AutoTrackBtnSelected);
        }
    }

}


function R30onAutoFramBtn(event) {
    var btnType = event.button;
    //如果不是左键则返回
    if (0 != btnType) {
        return;
    }
    var strSubmData = "";
    if (m_OnAutoFramBtnSelected) {
        m_OnAutoFramBtnSelected = false;
    } else {
        m_OnAutoFramBtnSelected = true;
    }
    R30setFramStyle(m_OnAutoFramBtnSelected);
    strSubmData = "&cAutoFramingStatus=" + ((m_OnAutoFramBtnSelected == true) ? 1 : 0);
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL, strSubmData);  
}

function R30onFramMouseOver(obj) {
    if(document.getElementById("R30autoFramBtnId").disabled == true)
    {
        return;
    }
    if (!m_OnAutoFramBtnSelected) {
        R30setFramStyle(true);
    }
}

function R30onFramMouseOut(obj) {
    if(document.getElementById("R30autoFramBtnId").disabled == true)
    {
        return;
    }
    if (!m_OnAutoFramBtnSelected) {
        R30setFramStyle(false);
    }  
}

function R30setFramStyle(bSelect) {
    var imgCSS;
    if (bSelect) {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_hover.png) no-repeat';
    }
    else {
        imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_normal.png) no-repeat';
    }
    $("#R30autoFramBtnId").css('background', imgCSS);
}

function onFramingCorrectiveBtn(event)
{
    var strSubmData = "";
    strSubmData = "&cFramingCorrective=" + "1";
    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL, strSubmData);  
}

function onSwnsitivitySwitchChange() {
    //获取被选中状态
    var status = document.getElementById("sensitivityId").value;
    ///状态根据不同模式发送到FCGI程序
    var strSubmData = "";

    strSubmData = "&cFramingSwnsitivitystatus=" + status;
    m_CurrFramingSwnsi = status;

    strSubmData = "begin&Operation=SetDivContent" + strSubmData + "&SubmitData=end";
    SendInformation(PageRefDesURL, strSubmData);
}


const getWindowInfo = () => {
    var resolution = window.screen.width;
    var BrowserWidth = window.innerWidth;
    if(resolution <= 1024 || BrowserWidth <= 1024)
    {
        $("#ptzCtrlTitleId").hide();
        $("#cameraNameLabelId").hide();
        $("#cameraLocLabelId").hide();
        $("#cameraid").show();
        $("#Locationid").show();   
    }
    else
    {
        $("#ptzCtrlTitleId").show();
        $("#cameraNameLabelId").show();
        $("#cameraLocLabelId").show();
        $("#cameraid").hide();
        $("#Locationid").hide();
    }
    
};


const debounce = (fn, delay) => {
	let timer;
	return function() {
		if (timer) {
			clearTimeout(timer);
		}
		timer = setTimeout(() => {
			fn();
		}, delay);
	}
};
const cancalDebounce = debounce(getWindowInfo, 500);

var m_TrackStatus = 0;
function onSpeedCompMouseover()
{
    if(1 == m_TrackStatus)
    {
        $('#ptzSpeedCompSwitchBtnId').attr('onclick','');
        document.getElementById("ptzSpeedCompSwitchBtnId").style = "cursor: not-allowed; ";
    }
    else
    {
        $('#ptzSpeedCompSwitchBtnId').attr('onclick','onSwitchBtnClick(event,this)');
        document.getElementById("ptzSpeedCompSwitchBtnId").style = "cursor: auto; ";
        setSwitchBtnState("ptzSpeedCompSwitchBtnId");
    }
}

function getCameraSettingsValue() {
    var req = "do?id=1&id=1&Operation=GetDivContent&DivName=divGetCameraSettingsValue";
    $.ajax
    (
        {
            url: req,
            cache: false,
            success: function (html) 
            {
                //清空div子项
                $("#GetCameraSettingsValueId").empty();
                //解析
                $("#GetCameraSettingsValueId").append(html);
                var f2 = document.getElementById("GetCameraSettingsValueId").getElementsByTagName("form")["hiddenValForm_Div"];
          
                //console.log("html:%s", html);
        
                //每次重新请求CameraSetting的页面
                document.getElementById("epModeId").value = f2.hcImageExposureMode.value;
                var epMode = f2.hcImageExposureMode.value;
                $('#epModeId').val(epMode);
                setExposureMode($('option:selected', '#epModeId').index());
            
                curGainLimitIndex = gainLimitVal.indexOf(TransEmptyStrTo0(f2.hcImageExposureGainLimit.value));
                document.getElementById("gainLimitInputId").value = gainLimitArr[curGainLimitIndex];
                document.getElementById("epCompLvlInputId").value = TransEmptyStrTo0(f2.hcImageExposureLevel.value);
                $('#wdrsId').val(TransEmptyStrTo0(f2.hcImageExposureWDR.value));
                curIrisIndex = irisParamVal.indexOf(f2.hcImageExposureIris.value);
                document.getElementById("irisInputId").value = irisParamArr[curIrisIndex];
                curShutterSpeedIndex = shutterSpeedParamVal.indexOf(f2.hcImageExposureShutter.value);
                gCurFrameRate = document.forms["hiddenValForm"].hcmainFrameRate.value;
                if("30" == gCurFrameRate)
                {
                    document.getElementById("shutterSpeedInputId").value = shutterSpeedParamArr[curShutterSpeedIndex];
                }
                else if("25" == gCurFrameRate)
                {
                    document.getElementById("shutterSpeedInputId").value = shutterSpeedParam25Arr[curShutterSpeedIndex];
                }
                curGainIndex = gainParamVal.indexOf(f2.hcImageExposureGain.value);
                document.getElementById("gainInputId").value = gainParamArr[curGainIndex];
                var wbMode = f2.hcImageWhileMode.value;
                $('#wbModeId').val(wbMode);
                setWhileMode(wbMode);
                document.getElementById("manualRedInputID").value = TransEmptyStrTo0(f2.hcImageWhileManualRed.value);
                document.getElementById("manualBlueInputID").value = TransEmptyStrTo0(f2.hcImageWhileManualBlue.value);
                $('#afSensitivitiesId').val(TransEmptyStrTo0(f2.hcImageFocusSensitivity.value));
                $('#afFrameId').val(TransEmptyStrTo0(f2.hcImageFocusAFFrame.value));
                document.getElementById("ptzAssistSwitchBtnId").value = TransEmptyStrTo0(f2.hcImageFocusPTZAssist.value);
                setPanTiltLimMode(parseInt(TransEmptyStrTo0(f2.hcPtzLimitEnable.value)));
                document.getElementById("panRightLimitInputId").value = TransEmptyStrTo0(f2.hcPtzRightLimit.value);
                document.getElementById("panLeftLimitInputId").value = TransEmptyStrTo0(f2.hcPtzLeftLimit.value);
                document.getElementById("tiltUpLimitInputId").value = TransEmptyStrTo0(f2.hcPtzUpLimit.value);
                document.getElementById("tiltDownLimitInputId").value = TransEmptyStrTo0(f2.hcPtzDownLimit.value);
                $('#presetSpeedId').val(TransEmptyStrTo0(f2.hcPtzPresetSpeed.value));
                $('#initialPosId').val(TransEmptyStrTo0(f2.hcPtzInitialPosition.value));
                $('#dZoomLimId').val(TransEmptyStrTo0(f2.hcPtzDZoomLimit.value));
                document.getElementById("ptzSpeedCompSwitchBtnId").value = TransEmptyStrTo0(f2.hcPtzSpeedComp.value);
                setSwitchBtnState("ptzSpeedCompSwitchBtnId");
                console.log("hcAutoTrackingStatus  = %s",f2.hcAutoTrackingStatus.value)
                if(1 == f2.hcAutoTrackingStatus.value)
                {
                    m_TrackStatus = 1;
                }
                else{
                    m_TrackStatus = 0;
                }
               
                document.getElementById("motionlessPresetSwitchBtnId").value = TransEmptyStrTo0(f2.hcPtzMotionlessPreset.value);
                setSwitchBtnState("motionlessPresetSwitchBtnId");
                $('#2dNRSelId').val(TransEmptyStrTo0(f2.hcImage2DNR.value));
                $('#3dNRSelId').val(TransEmptyStrTo0(f2.hcImage3DNR.value));
                var imageMode = f2.hcImageMode.value;
                $('#imageModeSelId').val(imageMode);
                setImageMode(imageMode);
                document.getElementById("gammaInputID").value = TransEmptyStrTo0(f2.hcImageGamma.value);
                document.getElementById("brightnessInputID").value = TransEmptyStrTo0(f2.hcImageBrightness.value);
                document.getElementById("hueInputID").value = TransEmptyStrTo0(f2.hcImageHue.value);
                document.getElementById("saturateInputID").value = TransEmptyStrTo0(f2.hcImageSaturation.value);
                document.getElementById("sharpInputID").value = TransEmptyStrTo0(f2.hcImageSharpness.value);
            }
        }
    );
}

var m_getTrackStatusCount = 0;
//定时获取状态
function getTrackStatus() {
    var req = "do?id=1&id=1&Operation=GetDivContent&DivName=divGetTrackStatus";
    $.ajax({
        url: req,
        cache: false,
        success: function (html) {
            console.log(m_getTrackStatusCount);
            //定制器
            if(m_getTrackStatusCount < 10)
            {
                setTimeout("getTrackStatus()", 1000);
            }
            m_getTrackStatusCount ++;
            //清空div子项
            $("#TrackStatusDivId").empty();
            //解析
            $("#TrackStatusDivId").append(html);

            var f2 = document.getElementById("TrackStatusDivId").getElementsByTagName("form")["hiddenValForm_Div"];
            // var totalPeopleCount = parseInt(f2.hcPeopleCount.value);
            //console.log("totalPeopleCount:%d", totalPeopleCount);
            //赋值
            if (parseInt(f2.hcTrackingModecurvalue.value) == 3 || parseInt(f2.hcTrackingModecurvalue.value) == 4)
            {
                document.getElementById("autoTrackBtnId").disabled = true;
                document.getElementById("autoFramBtnId").disabled = false;
                imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_disable.png) no-repeat';
                $("#autoTrackBtnId").css('background', imgCSS);
                
                if (parseInt(f2.hcAutoTrackingStatus.value) == 1) {//自动取景功能开启
                    m_OnAutoFramBtnSelected = true;
                    setFramStyle(m_OnAutoFramBtnSelected);
                }
            }
            else if (parseInt(f2.hcTrackingModecurvalue.value) == 5)
            {
                document.getElementById("autoTrackBtnId").disabled = true;
                document.getElementById("autoFramBtnId").disabled = true;
                imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_disable.png) no-repeat';
                $("#autoFramBtnId").css('background', imgCSS);
                imgCSS = 'url(../images/MainView/Ptz/btn_auto-tracking_Property_1_auto-tracking__Property_2_disable.png) no-repeat';
                $("#autoTrackBtnId").css('background', imgCSS);
            }
            else
            {
                document.getElementById("autoFramBtnId").disabled = true;
                document.getElementById("autoTrackBtnId").disabled = false;
                imgCSS = 'url(../images/MainView/Ptz/btn_auto-framing_Property_1_auto-framing__Property_2_disable.png) no-repeat';
                $("#autoFramBtnId").css('background', imgCSS);
                
                if (parseInt(f2.hcAutoTrackingStatus.value) == 1) {//自动跟踪功能开启
                    m_AutoTrackBtnSelected = true;
                    setTrackStyle(m_AutoTrackBtnSelected);
                }
            }
        }
    });
}

