var CurPage = ""
var m_bFlagTrackModeSwitch = false;

 class WebsocketMsg{
    channel;
    MaxErrorNum;
    
    constructor(channel,MaxErrorNum) {
        this.channel = channel;
        this.MaxErrorNum = MaxErrorNum;
        return this;
    }
    
    ws = undefined;
    isExit = false;
    ErrorNum = 0;
  
    prepareSocket() {
      // if https then use wss
        var socketURL = '';
        var hostIP = "";
        if (location.host.toLowerCase().indexOf(':') != -1) {
            hostIP = location.host.split(':')[0];
        } else {
            hostIP = location.host;
        }

        if (location.protocol.toLowerCase().indexOf('https') != -1)
        {
            socketURL = `ws://${hostIP}:12350/event`;
        } else {
            socketURL = `ws://${hostIP}:12350/event`;
        }
        

  
      // try clean old socket
      this.ws?.close();
      this.ws = undefined;
      if (this.isExit) return; // close by destroy
  
      try {
        this.ws = new WebSocket(socketURL);
        this.ws.binaryType = 'arraybuffer';
      } catch (err) {
        console.log(`create socket to ${socketURL} failed. Please check network and server.`);
        return;
      }
  
      this.ws.addEventListener('message', (event) => {
          console.log(event.data);
          OnMassage(event.data);
      });
  
      // compat with wfs, call server start push stream
      const openMessage = JSON.stringify({
        t: 'open',
        c: this.channel,
        v: 'NA',
      })
      this.ws.onopen = (ev) => {
        this.ws?.send(openMessage);
        console.log("Socket connect success.");
      }
      this.ws.onerror = (ev) => {
        console.log("Socket Error, try reconnect...");
        destroy();
        this.prepareSocket();
      }
      this.ws.onclose = (ev) => {
        if (this.isExit) {
          console.log("Socket closed.");
          return; // close by destroy
        }
        console.log("Socket connection lost, try reconnect...");
        this.prepareSocket();
      }
    }
  
    play() {
      this.isExit = false;
      this.prepareSocket();
    }
  
    destroy() {
      this.isExit = true; // do't auto reconnect
      this.ws?.close();
      this.ws = undefined;
    }
  }


  function OnMassage(Msg)
  {
    var Object = eval('(' + Msg + ')');
    console.log(CurPage);
    console.log(Object.event);
    console.log(Object.data);
    if(CurPage == "trackView"){
        if(Object.event == "AutoTracking"){
            var Date = Object.data.split(",")
            if(Date[0] == "1"){
                var mode = document.getElementById("trackModeId").value;
                if(Date[1]!=null)
                {
                    mode = Date[1];
                    document.getElementById("trackModeId").value = mode;
                    m_TrackModevalue = mode;
                    onTrackingModeSwitchChange();
                }
                if(mode == 0 || mode == 1 || mode == 2){
                    m_AutoTrackBtnSelected = true;
                    onAutoTrackOpen();
                }else if(mode == 3 || mode == 4){
                    m_OnAutoFramBtnSelected = true;
                    onAutoFramOpen()
                }else if(mode == 5){
                    m_AutoTrackBtnSelected = true;
                    OnCenterStageOpen()
                }

            }else if(Date[0] == "0"){
                var mode = document.getElementById("trackModeId").value;
                if(Date[1]!=null)
                {
                    mode = Date[1];
                    document.getElementById("trackModeId").value = mode;
                    m_TrackModevalue = mode;
                }
                if(mode == 0 || mode == 1 || mode == 2){
                    m_AutoTrackBtnSelected = false;
                    onAutoTrackOpen();
                }else if(mode == 3 || mode == 4){
                    m_OnAutoFramBtnSelected = false;
                    onAutoFramOpen()
                }else if(mode == 5){
                    m_AutoTrackBtnSelected = false;
                    OnCenterStageOpen()
                }
            }
        }else if(Object.event == "TrackModeSwitch"){
            if(Object.data == "1"){
                m_bFlagTrackModeSwitch = true;
            }else{
                m_bFlagTrackModeSwitch = false;
            }
        }
    }if(CurPage == "liveView"){
        if(Object.event == "AutoTracking"){
            var Date = Object.data.split(",")
            var f2 = document.forms["hiddenValForm"];
            if(Date[0] == "1"){
                var mode = f2.hcTrackingModecurvalue.value;
                if(Date[1]!=null)
                {
                    mode = Date[1];
                }
                if(mode == 0 || mode == 1 || mode == 2 || mode == 5){
                    m_AutoTrackBtnSelected = true;
                    setTrackStyle(m_AutoTrackBtnSelected);
                }else if(mode == 3 || mode == 4){
                    m_OnAutoFramBtnSelected = true;
                    setFramStyle(m_OnAutoFramBtnSelected);
                }
            }else if(Date[0] == "0"){
                var mode = f2.hcTrackingModecurvalue.value;
                if(Date[1]!=null)
                {
                    mode = Date[1];
                }
                if(mode == 0 || mode == 1 || mode == 2 || mode == 5){
                    m_AutoTrackBtnSelected = false;
                    setTrackStyle(m_AutoTrackBtnSelected);
                }else if(mode == 3 || mode == 4){
                    m_OnAutoFramBtnSelected = false;
                    setFramStyle(m_OnAutoFramBtnSelected);
                }
            }
        }
    }else{
        return;
    }
  }

  