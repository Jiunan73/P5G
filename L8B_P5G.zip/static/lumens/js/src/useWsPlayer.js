/******************************
 * A video player get raw h264 video from websocket
 *    Socket Management: custom
 *    H264 to MediaSource: power by https://github.com/samirkumardas/jmuxer
 **/

class Player {
  channel;
  elementId;
  fps;

  encoder = undefined;
  ws = undefined;
  isExit = false;

  constructor(elementId, channel, fps = 30) {
    this.elementId = elementId;
    this.channel = channel;
    this.fps = fps;
    return this;
  }

  prepareEncoder() {
    this.encoder = new JMuxer({
      node: this.elementId,
      mode: 'video',
      flushingTime: 0,
      fps: this.fps,
      debug: false,
      onReady: () => {
        // once mse ready, then play
        document.getElementById(this.elementId)?.play();
      },
      onError: (data) => {
        console.log('Buffer error encountered', data);
        this.encoder.reset();
      },
      onMissingVideoFrames: (data) => {
        if (data.length > 0)
          console.log('Video frames missing', data);
      },
    });
  }

  prepareSocket() {
    // if https then use wss
      var socketURL = '';
      var hostIP = "";
      if (location.host.toLowerCase().indexOf(':') != -1) {
          hostIP = location.host.split(':')[0];
      } else {
          hostIP = location.host;
      }
      if (location.protocol.toLowerCase().indexOf('https') != -1)
      {
          socketURL = `wss://${hostIP}:12346/play2`;
      } else {
          socketURL = `ws://${hostIP}:12345/play2`;
      }

    // try clean old socket
    this.ws?.close();
    this.ws = undefined;
    if (this.isExit) return; // close by destroy

    try {
      this.ws = new WebSocket(socketURL);
      this.ws.binaryType = 'arraybuffer';
    } catch (err) {
      console.log(`create socket to ${socketURL} failed. Please check network and server.`);
      return;
    }

    this.ws.addEventListener('message', (event) => {
      this.encoder.feed({ video: new Uint8Array(event.data), });
    });

    // compat with wfs, call server start push stream
    const openMessage = JSON.stringify({
      t: 'open',
      c: this.channel,
      v: 'NA',
    })
    this.ws.onopen = (ev) => {
      this.ws?.send(openMessage);
      console.log("Socket connect success.");
    }
    this.ws.onerror = (ev) => {
      console.log("Socket Error, try reconnect...");
      this.prepareSocket();
    }
    this.ws.onclose = (ev) => {
      if (this.isExit) {
        console.log("Socket closed.");
        return; // close by destroy
      }
      console.log("Socket connection lost, try reconnect...");
      this.prepareSocket();
    }
  }

  play() {
    this.isExit = false;
    this.prepareEncoder();
    this.prepareSocket();
  }

  destroy() {
    this.isExit = true; // do't auto reconnect
    this.ws?.close();
    this.ws = undefined;
    this.encoder = undefined;
  }
}

function isSupport() {
  return JMuxer.isSupport('video/mp4; codecs="avc1.42E01E"'); //, mp4a.40.2"'); // no audio
}